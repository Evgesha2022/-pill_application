function addTablet(t_name, t_date_start, t_duration, dozen,  time, t_state, context) {
    addAction({
        type: "add_tablet",
        name: t_name,
        date_start: t_date_start,
        period: t_duration,
        times: time,
        doza: dozen,
        condition: t_state
    }, context);
}


function deletePill(id, times, context){
    addAction({
        type: "delete_tablet_one_time",
        name: id,
        time: times
    }, context);
}

function mark_pill(id, times, context){
    addAction({
        type: "mark_pill",
        name: id,
        time: times
    }, context);
}

function delete_all_Pill(id, context){
    addAction({
        type: "delete_all_pills",
        name: id
    }, context);
}

function add_user(t_name, t_surname, t_date, context){
    addAction({
        type: "add_new_user",
        name: t_name,
        surname: t_surname,
        birthdate: t_date
    }, context);
}